<?php
/*
Page: piklist_demo_bulk_create
*/

  // Embed a Piklist form
  // From: piklist/add-ons/piklist-demos/parts/forms/bulk-create.php

  piklist('form', array(
    'form' => 'bulk-create'
  ));