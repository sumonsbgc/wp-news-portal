<?php
/*
Post Type: piklist_demo,page
Flow: Demo Workflow
Tab: Extend
Extend: piklist_demos_meta_box_extend
Extend Method: after
*/
?>

<p>
  <?php _e('I am extended!', 'piklist-demos'); ?>
</p>
