<?php

namespace Eis\ThemeOption;

use Eis\ThemeOption\Frontend\Shortcode;

class Frontend
{
    public function __construct()
    {
        new Shortcode();
    }
}
