<?php

/**
 * Single Post Template - Default Layout (fallback)
 */

$templateManager = SinglePageTemplateManager::getInstance();
$post_id = get_the_ID();

get_header(); ?>

<main class="single-default">
  <div class="container mx-auto px-4 py-8">
    <div class="grid lg:grid-cols-3 gap-8">
      <div class="lg:col-span-2">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <?php echo $templateManager->renderPostContent($post_id, 'default'); ?>
        <?php endwhile;
        endif; ?>
      </div>
      <div class="lg:col-span-1">
        <?php get_sidebar(); ?>
      </div>
    </div>
  </div>
</main>

<?php get_footer(); ?>