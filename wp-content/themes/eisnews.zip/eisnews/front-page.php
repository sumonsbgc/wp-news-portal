<?php

// Create page controller and render homepage
$pageController = new PageController();
$pageController->renderHomepage();