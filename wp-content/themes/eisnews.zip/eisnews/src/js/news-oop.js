jQuery(document).ready(function ($) {
	"use strict";

	// OOP-based tab switching
	class NewsTabManager {
		constructor() {
			this.init();
		}

		init() {
			this.bindEvents();
			this.preloadContent();
		}

		bindEvents() {
			$(".tab-filter").on("click", (e) => this.handleTabClick(e));
			$(".tab-filter:not(.active)").on("mouseenter", (e) =>
				this.handleTabHover(e)
			);
		}

		handleTabClick(e) {
			e.preventDefault();

			const $tab = $(e.currentTarget);
			const category = $tab.data("category");
			const borderColor = $tab.data("border-color");
			const bgColor = $tab.data("bg-color");

			if ($tab.hasClass("active")) {
				return;
			}

			this.setActiveTab($tab);
			this.loadTabContent(category, borderColor, bgColor);
		}

		handleTabHover(e) {
			const $tab = $(e.currentTarget);
			const category = $tab.data("category");

			// Preload content on hover
			clearTimeout($tab.data("preloadTimeout"));
			$tab.data(
				"preloadTimeout",
				setTimeout(() => {
					this.preloadTabContent(category);
				}, 500)
			);
		}

		setActiveTab($activeTab) {
			$(".tab-filter").removeClass("active");
			$activeTab.addClass("active");
		}

		loadTabContent(category, borderColor, bgColor, isPreload = false) {
			const existingContent = $("#" + category);

			if (existingContent.length && existingContent.html().trim() !== "") {
				if (!isPreload) {
					$(".tab-content__wrapper").removeClass("active");
					existingContent.addClass("active");
				}
				return;
			}

			if (!isPreload) {
				$(".tab-contents").addClass("loading");
			}

			this.makeAjaxRequest(
				{
					action: "get_tab_news",
					category: category,
					borderColor: borderColor,
					bgColor: bgColor,
				},
				(response) => {
					this.handleTabResponse(response, category, borderColor, isPreload);
				}
			);
		}

		preloadTabContent(category) {
			const $tab = $(`.tab-filter[data-category="${category}"]`);
			const borderColor = $tab.data("border-color");
			const bgColor = $tab.data("bg-color");

			this.loadTabContent(category, borderColor, bgColor, true);
		}

		preloadContent() {
			// Preload first inactive tab
			const $firstInactive = $(".tab-filter:not(.active)").first();
			if ($firstInactive.length) {
				setTimeout(() => {
					const category = $firstInactive.data("category");
					this.preloadTabContent(category);
				}, 2000);
			}
		}

		handleTabResponse(response, category, borderColor, isPreload) {
			if (response.success) {
				$(".tab-content__wrapper").removeClass("active");

				let $targetContent = $("#" + category);
				if ($targetContent.length === 0) {
					$targetContent = $(
						`<div class="tab-content__wrapper relative tab-content border-y-2 p-4 ${borderColor}" id="${category}"></div>`
					);
					$(".tab-contents").append($targetContent);
				}

				$targetContent.html(response.data);

				if (!isPreload) {
					$targetContent.addClass("active");
				}
			} else {
				console.error("Tab loading failed:", response.data);
			}

			$(".tab-contents").removeClass("loading");
		}

		makeAjaxRequest(data, successCallback) {
			$.ajax({
				url: newsAjax.ajaxUrl,
				type: "POST",
				data: {
					...data,
					nonce: newsAjax.nonce,
				},
				success: successCallback,
				error: (xhr, status, error) => {
					console.error("AJAX Request failed:", error);
					$(".tab-contents").removeClass("loading");
				},
			});
		}
	}

	// Load More News functionality
	class LoadMoreManager {
		constructor() {
			this.init();
		}

		init() {
			this.bindEvents();
		}

		bindEvents() {
			$(document).on("click", ".load-more-btn", (e) => this.handleLoadMore(e));
		}

		handleLoadMore(e) {
			e.preventDefault();

			const $btn = $(e.currentTarget);
			const category = $btn.data("category");
			const page = parseInt($btn.data("page")) + 1;
			const perPage = $btn.data("per-page") || 4;

			$btn.addClass("loading").text("Loading...");

			this.makeAjaxRequest(
				{
					action: "load_more_news",
					category: category,
					page: page,
					per_page: perPage,
				},
				(response) => {
					this.handleLoadMoreResponse(response, $btn, page);
				}
			);
		}

		handleLoadMoreResponse(response, $btn, page) {
			if (response.success) {
				const $container = $btn.closest(".news-section").find(".news-grid");
				$container.append(response.data.html);

				$btn.data("page", page);

				if (!response.data.has_more) {
					$btn.hide();
				} else {
					$btn.removeClass("loading").text("Load More");
				}
			} else {
				console.error("Load more failed:", response.data);
				$btn.removeClass("loading").text("Load More");
			}
		}

		makeAjaxRequest(data, successCallback) {
			$.ajax({
				url: newsAjax.ajaxUrl,
				type: "POST",
				data: {
					...data,
					nonce: newsAjax.nonce,
				},
				success: successCallback,
				error: (xhr, status, error) => {
					console.error("Load More AJAX failed:", error);
				},
			});
		}
	}

	// Initialize managers
	if ($(".tab-filter").length) {
		new NewsTabManager();
	}

	if ($(".load-more-btn").length) {
		new LoadMoreManager();
	}
});
