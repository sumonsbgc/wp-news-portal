jQuery(document).ready(function ($) {
	"use strict";

	// Optimized tab switching with better caching
	$(".tab-filter").on("click", function (e) {
		e.preventDefault();

		const $this = $(this);
		const category = $this.data("category");
		const borderColor = $this.data("border-color");
		const bgColor = $this.data("bg-color");

		// Don't reload if already active
		if ($this.hasClass("active")) {
			return;
		}

		// Update active states
		$(".tab-filter").removeClass("active");
		$this.addClass("active");

		// Check if content is already loaded
		const existingContent = $("#" + category);
		if (existingContent.length && existingContent.html().trim() !== "") {
			$(".tab-content__wrapper").removeClass("active");
			existingContent.addClass("active");
			return;
		}

		// Show loading state
		const $contentWrapper = $(".tab-contents");
		$contentWrapper.addClass("loading");

		// AJAX call with optimized endpoint
		$.ajax({
			url: ajaxTabData.ajaxUrl,
			type: "POST",
			data: {
				action: "tabnews_optimized",
				category: category,
				borderColor: borderColor,
				bgColor: bgColor,
				nonce: ajaxTabData.nonce,
			},
			success: function (response) {
				if (response.success) {
					// Remove existing active content
					$(".tab-content__wrapper").removeClass("active");

					// Create or update content
					let $targetContent = $("#" + category);
					if ($targetContent.length === 0) {
						$targetContent = $(
							'<div class="tab-content__wrapper relative tab-content border-y-2 p-4 ' +
								borderColor +
								'" id="' +
								category +
								'"></div>'
						);
						$contentWrapper.append($targetContent);
					}

					$targetContent.html(response.data).addClass("active");
				} else {
					console.error("AJAX Error:", response.data);
				}
			},
			error: function (xhr, status, error) {
				console.error("AJAX Request failed:", error);
			},
			complete: function () {
				$contentWrapper.removeClass("loading");
			},
		});
	});

	// Preload next tab content on hover for better UX
	$(".tab-filter:not(.active)").on("mouseenter", function () {
		const $this = $(this);
		const category = $this.data("category");

		// Only preload if not already loaded
		const existingContent = $("#" + category);
		if (existingContent.length === 0 || existingContent.html().trim() === "") {
			// Debounce the preload to avoid excessive requests
			clearTimeout($this.data("preloadTimeout"));
			$this.data(
				"preloadTimeout",
				setTimeout(function () {
					// Trigger a silent preload
					$this.trigger("click");
				}, 500)
			);
		}
	});
});
