/**
 * Infinite Scroll for Single Posts
 */
(function ($) {
	"use strict";

	class InfiniteScroll {
		constructor() {
			this.currentPage = 1;
			this.loading = false;
			this.hasMore = true;
			this.postId = infiniteScroll.post_id;
			this.container = $("#infinite-posts");
			this.loadingIndicator = $("#infinite-loading");

			this.init();
		}

		init() {
			this.bindEvents();
			this.loadInitialPosts();
		}

		bindEvents() {
			$(window).on("scroll", this.handleScroll.bind(this));
		}

		handleScroll() {
			if (this.loading || !this.hasMore) {
				return;
			}

			const scrollTop = $(window).scrollTop();
			const windowHeight = $(window).height();
			const documentHeight = $(document).height();
			const scrollPercentage = (scrollTop + windowHeight) / documentHeight;

			// Load more when user has scrolled 80% of the page
			if (scrollPercentage > 0.8) {
				this.loadMore();
			}
		}

		loadInitialPosts() {
			this.loadMore();
		}

		loadMore() {
			if (this.loading || !this.hasMore) {
				return;
			}

			this.loading = true;
			this.showLoading();

			const data = {
				action: "load_infinite_posts",
				nonce: infiniteScroll.nonce,
				post_id: this.postId,
				page: this.currentPage,
			};

			$.ajax({
				url: infiniteScroll.ajaxurl,
				type: "POST",
				data: data,
				success: this.handleSuccess.bind(this),
				error: this.handleError.bind(this),
				complete: this.handleComplete.bind(this),
			});
		}

		handleSuccess(response) {
			if (response.success && response.data) {
				const posts = response.data.posts;
				const hasMore = response.data.has_more;

				if (posts && posts.length > 0) {
					this.appendPosts(posts);
					this.currentPage++;
				}

				this.hasMore = hasMore;

				if (!hasMore) {
					this.showEndMessage();
				}
			} else {
				this.hasMore = false;
				this.showEndMessage();
			}
		}

		handleError(xhr, status, error) {
			console.error("Infinite scroll error:", error);
			this.hasMore = false;
			this.showErrorMessage();
		}

		handleComplete() {
			this.loading = false;
			this.hideLoading();
		}

		appendPosts(posts) {
			posts.forEach((post) => {
				const postHtml = this.createPostHtml(post);
				const $post = $(postHtml).addClass("fade-in");
				this.container.append($post);
			});
		}

		createPostHtml(post) {
			const thumbnailHtml = post.thumbnail
				? `<div class="infinite-post-thumbnail">
                    <a href="${post.permalink}">
                        <img src="${post.thumbnail}" alt="${post.title}" loading="lazy">
                    </a>
                </div>`
				: "";

			return `
                <article class="infinite-post-item">
                    ${thumbnailHtml}
                    <div class="infinite-post-content">
                        <h3>
                            <a href="${post.permalink}">${post.title}</a>
                        </h3>
                        <div class="infinite-post-excerpt">${post.excerpt}</div>
                        <div class="infinite-post-meta">
                            <span class="post-date">${post.date}</span>
                            <span class="post-author">By ${post.author}</span>
                            ${
															post.categories
																? `<span class="post-categories">${post.categories}</span>`
																: ""
														}
                        </div>
                    </div>
                </article>
            `;
		}

		showLoading() {
			this.loadingIndicator.removeClass("hidden").addClass("flex");
		}

		hideLoading() {
			this.loadingIndicator.removeClass("flex").addClass("hidden");
		}

		showEndMessage() {
			if ($("#infinite-end-message").length === 0) {
				const endMessage = `
                    <div id="infinite-end-message" class="text-center py-8 text-gray-500">
                        <p>You've reached the end of related articles.</p>
                    </div>
                `;
				this.container.after(endMessage);
			}
		}

		showErrorMessage() {
			if ($("#infinite-error-message").length === 0) {
				const errorMessage = `
                    <div id="infinite-error-message" class="text-center py-8 text-red-500">
                        <p>Sorry, we couldn't load more articles. Please try again later.</p>
                        <button id="retry-infinite-scroll" class="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                            Try Again
                        </button>
                    </div>
                `;
				this.container.after(errorMessage);

				$("#retry-infinite-scroll").on("click", () => {
					$("#infinite-error-message").remove();
					this.hasMore = true;
					this.loadMore();
				});
			}
		}
	}

	// Initialize when DOM is ready
	$(document).ready(function () {
		if (typeof infiniteScroll !== "undefined") {
			new InfiniteScroll();
		}
	});
})(jQuery);
