/**
 * Parallax Effects for Single Posts
 */
(function ($) {
	"use strict";

	class ParallaxEffect {
		constructor() {
			this.parallaxElements = $(".parallax-hero");
			this.isSupported = this.checkSupport();

			if (this.isSupported && this.parallaxElements.length > 0) {
				this.init();
			}
		}

		checkSupport() {
			// Disable parallax on touch devices for better performance
			const isTouchDevice =
				"ontouchstart" in window || navigator.maxTouchPoints > 0;
			const isReducedMotion = window.matchMedia(
				"(prefers-reduced-motion: reduce)"
			).matches;

			return !isTouchDevice && !isReducedMotion;
		}

		init() {
			this.setupParallaxElements();
			this.bindEvents();
			this.updateParallax(); // Initial call
		}

		setupParallaxElements() {
			this.parallaxElements.each((index, element) => {
				const $element = $(element);
				const bgImage = $element.data("bg");

				if (bgImage) {
					$element.css({
						"background-image": `url(${bgImage})`,
						"background-attachment": "fixed",
						"background-position": "center",
						"background-repeat": "no-repeat",
						"background-size": "cover",
					});
				}
			});
		}

		bindEvents() {
			let ticking = false;

			$(window).on("scroll", () => {
				if (!ticking) {
					requestAnimationFrame(() => {
						this.updateParallax();
						ticking = false;
					});
					ticking = true;
				}
			});

			$(window).on(
				"resize",
				this.debounce(() => {
					this.updateParallax();
				}, 250)
			);
		}

		updateParallax() {
			const scrollTop = $(window).scrollTop();
			const windowHeight = $(window).height();

			this.parallaxElements.each((index, element) => {
				const $element = $(element);
				const elementTop = $element.offset().top;
				const elementHeight = $element.outerHeight();

				// Check if element is in viewport
				if (
					elementTop + elementHeight >= scrollTop &&
					elementTop <= scrollTop + windowHeight
				) {
					const rate = (scrollTop - elementTop) / elementHeight;
					const yPos = Math.round(rate * 50); // Adjust speed by changing multiplier

					$element.css({
						"background-position": `center ${yPos}px`,
					});

					// Apply parallax to content within the hero
					const $heroContent = $element.find(".hero-content");
					if ($heroContent.length > 0) {
						const contentYPos = Math.round(rate * 20); // Slower movement for content
						$heroContent.css({
							transform: `translateY(${contentYPos}px)`,
						});
					}
				}
			});
		}

		debounce(func, wait) {
			let timeout;
			return function executedFunction(...args) {
				const later = () => {
					clearTimeout(timeout);
					func(...args);
				};
				clearTimeout(timeout);
				timeout = setTimeout(later, wait);
			};
		}
	}

	// Smooth reveal animations
	class SmoothReveal {
		constructor() {
			this.revealElements = $(".parallax-content .post-content > *");
			this.init();
		}

		init() {
			this.setupRevealElements();
			this.bindScrollEvents();
		}

		setupRevealElements() {
			this.revealElements.css({
				opacity: "0",
				transform: "translateY(30px)",
				transition: "opacity 0.6s ease, transform 0.6s ease",
			});
		}

		bindScrollEvents() {
			let ticking = false;

			$(window).on("scroll", () => {
				if (!ticking) {
					requestAnimationFrame(() => {
						this.checkRevealElements();
						ticking = false;
					});
					ticking = true;
				}
			});

			// Initial check
			this.checkRevealElements();
		}

		checkRevealElements() {
			const windowTop = $(window).scrollTop();
			const windowBottom = windowTop + $(window).height();

			this.revealElements.each((index, element) => {
				const $element = $(element);
				const elementTop = $element.offset().top;

				// Reveal when element is 80% visible
				if (elementTop < windowBottom - 100 && !$element.hasClass("revealed")) {
					$element.addClass("revealed").css({
						opacity: "1",
						transform: "translateY(0)",
					});
				}
			});
		}
	}

	// Progress indicator
	class ReadingProgress {
		constructor() {
			this.progressBar = this.createProgressBar();
			this.contentArea = $(".parallax-content .post-content");

			if (this.contentArea.length > 0) {
				this.init();
			}
		}

		createProgressBar() {
			const progressHtml = `
                <div id="reading-progress" style="
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 0%;
                    height: 3px;
                    background: linear-gradient(90deg, #3b82f6, #1d4ed8);
                    z-index: 9999;
                    transition: width 0.1s ease;
                "></div>
            `;
			$("body").append(progressHtml);
			return $("#reading-progress");
		}

		init() {
			$(window).on("scroll", () => {
				this.updateProgress();
			});
		}

		updateProgress() {
			const windowTop = $(window).scrollTop();
			const windowHeight = $(window).height();
			const contentTop = this.contentArea.offset().top;
			const contentHeight = this.contentArea.outerHeight();

			// Calculate progress based on content area
			const scrollStart = contentTop - windowHeight;
			const scrollEnd = contentTop + contentHeight;
			const scrollTotal = scrollEnd - scrollStart;
			const scrollCurrent = Math.max(0, windowTop - scrollStart);

			const progress = Math.min(
				100,
				Math.max(0, (scrollCurrent / scrollTotal) * 100)
			);

			this.progressBar.css("width", `${progress}%`);
		}
	}

	// Initialize when DOM is ready
	$(document).ready(function () {
		// Only initialize on parallax template
		if ($(".single-parallax").length > 0) {
			new ParallaxEffect();
			new SmoothReveal();
			new ReadingProgress();
		}
	});
})(jQuery);
