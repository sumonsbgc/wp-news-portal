<div class="col-md-6">
    <?php get_template_part('templates/col-small-news'); ?>
</div>