<div class="col-md-3">
    <?php get_template_part('templates/col-small-news'); ?>
</div>