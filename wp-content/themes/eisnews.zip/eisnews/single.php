<?php

/**
 * Single Post Template - OOP Based
 */

// Create page controller and render single post
$pageController = new PageController();
$pageController->renderSinglePost();
