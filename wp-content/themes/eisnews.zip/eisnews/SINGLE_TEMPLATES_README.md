# Single Page Template System

This WordPress theme now includes a comprehensive single page template system with multiple layout options and interactive features.

## Available Templates

### 1. **Default Layout**

- Standard WordPress single post layout
- Includes sidebar
- Traditional blog post appearance
- **File**: `single-default.php`

### 2. **Full Width Layout**

- Removes sidebar for full-width content
- Hero image overlay with title
- Clean, modern design
- **File**: `single-full-width.php`
- **Features**: Hero sections, responsive design

### 3. **Full Width with Infinite Scroll**

- Full width layout plus infinite scroll functionality
- Automatically loads related posts as user scrolls
- AJAX-powered for smooth experience
- **File**: `single-full-width-infinite.php`
- **Features**: Infinite scroll, related posts, loading animations

### 4. **Parallax Effect**

- Stunning parallax scrolling effects
- Fixed background image with content overlay
- Reading progress indicator
- Smooth reveal animations
- **File**: `single-parallax.php`
- **Features**: Parallax backgrounds, reading progress, smooth animations

### 5. **Minimal Layout**

- Clean, distraction-free design
- Typography-focused
- Perfect for long-form content
- **File**: `single-minimal.php`
- **Features**: Clean typography, minimal distractions

### 6. **Magazine Style**

- Professional magazine-style layout
- Related posts sidebar
- Featured image hero section
- **File**: `single-magazine.php`
- **Features**: Magazine layout, related posts, professional design

## How to Use

### For Administrators:

1. Go to **Appearance > Page Templates** in WordPress admin
2. View available templates and their features
3. Read the usage instructions

### For Content Editors:

1. Edit any post in WordPress admin
2. Look for **"Single Page Template"** meta box in the right sidebar
3. Select desired template from radio button options
4. Update/publish the post
5. View the post on frontend to see the new layout

### For Developers:

Templates are managed by the `SinglePageTemplateManager` class located in `inc/SinglePageTemplateManager.php`.

## Technical Features

### CSS & Styling

- Responsive design for all screen sizes
- Custom CSS file: `assets/css/single-templates.css`
- Print-friendly styles
- Animation and transition effects

### JavaScript Features

- **Infinite Scroll**: `assets/js/infinite-scroll.js`

  - Automatic loading of related posts
  - Error handling and retry functionality
  - Loading indicators

- **Parallax Effects**: `assets/js/parallax.js`
  - Smooth parallax scrolling
  - Reading progress indicator
  - Content reveal animations
  - Performance optimized

### AJAX Functionality

- `InfiniteScrollHandler` class handles AJAX requests
- Loads related posts based on categories
- Fallback to random posts if no related content
- Proper nonce verification and error handling

### Admin Interface

- Dedicated admin page showing all templates
- Visual preview of each template type
- Feature explanations and usage instructions
- Custom meta box for template selection

## Customization

### Adding New Templates

1. Create new template file (e.g., `single-custom.php`)
2. Add template configuration to `SinglePageTemplateManager`
3. Implement rendering method in the manager class
4. Add corresponding CSS styles

### Modifying Existing Templates

- Edit template files in theme root directory
- Modify CSS in `assets/css/single-templates.css`
- Update JavaScript in respective files

### Template Structure

Each template follows this structure:

```php
<?php
$templateManager = SinglePageTemplateManager::getInstance();
$post_id = get_the_ID();

get_header(); ?>

<main class="single-template-class">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php echo $templateManager->renderPostContent($post_id, 'template-type'); ?>
    <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>
```

## Performance Considerations

- Lazy loading for images in infinite scroll
- Optimized JavaScript with requestAnimationFrame
- CSS transitions for smooth animations
- Mobile-optimized parallax effects
- Reduced motion support for accessibility

## Browser Support

- Modern browsers (Chrome, Firefox, Safari, Edge)
- Responsive design for mobile devices
- Graceful degradation for older browsers
- Accessibility features included

## Files Structure

```
wp-content/themes/eisnews/
├── single.php (default single template)
├── single-default.php
├── single-full-width.php
├── single-full-width-infinite.php
├── single-parallax.php
├── single-minimal.php
├── single-magazine.php
├── inc/
│   ├── SinglePageTemplateManager.php
│   ├── InfiniteScrollHandler.php
│   └── SinglePageTemplateAdmin.php
└── assets/
    ├── css/
    │   ├── single-templates.css
    │   └── admin-templates.css
    ├── js/
    │   ├── infinite-scroll.js
    │   └── parallax.js
    └── images/
        └── templates/ (preview images)
```

This system provides a flexible, user-friendly way to create varied single post experiences while maintaining code organization and performance.
