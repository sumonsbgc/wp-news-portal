<?php
// Get current category slug
$qb = get_queried_object();
$categorySlug = $qb->slug;

// Create page controller and render category page
$pageController = new PageController();
$pageController->renderCategoryPage($categorySlug);