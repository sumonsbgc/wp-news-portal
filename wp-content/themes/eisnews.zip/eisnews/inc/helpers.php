<?php

use JetBrains\PhpStorm\NoReturn;

function eis_main_news_section_title($title = "প্রধান খবর", $title_class = null, $cat_class = null): string
{
  return sprintf(
    '<div class="bg-black-light border-none mb-3 %2$s">
        <span class="main_section_cat %3$s">%1$s</span>
     </div>',
    strtoupper($title),
    $title_class,
    $cat_class
  );
}

function eis_news_section_title($title = "Category One", $section_class = null, $cat_class = null, $link_class = null): string
{
  return sprintf(
    '<div class="flex justify-between items-center border-b mb-3 section_title %2$s">
      <a href="%5$s" class="text-lg px-2 pt-2 pb-[5px] text-white ml-2 %3$s">%1$s</a>
      <a href="%5$s" class="text-black flex items-center gap-2 %4$s">
        <span class="text-lg pt-[2px]">আরোও</span> <span>%6$s</span>
      </a>
    </div>',
    strtoupper(eis_get_category_name($title)),
    $section_class,
    $cat_class,
    $link_class,
    eis_get_category_link($title),
    get_svg_icon('right-angle'),
  );
}

function eis_news_single_title(): string
{
  return sprintf(
    '<div class="flex justify-between items-center border-b-2 border-primary mb-3">
                  <span class="text-lg px-3 pt-2 pb-[5px] text-white bg-primary">%1$s</span>
                </div>',
    strtoupper(single_cat_title('', false)),
  );
}

function eis_display_border($size = 2): void
{
  printf('<div class="border-top my-%s"></div>', $size);
}

function eis_section_title($template = null): void
{
  if ("main_news" === $template) {
    eis_main_news_section_title();
  } else {
    eis_news_section_title();
  }
}

function eis_short_title(string $title, int $length): string
{
  return substr($title, 0);
}

function eis_get_category_name($slug)
{
  $term = get_category_by_slug($slug);
  return $term->name;
}

function eis_get_category_link($slug): string
{
  $term = get_category_by_slug($slug);
  return get_category_link($term);
}


function get_template_part_as_string(string $slug, string|null $name = null, array $args = []): string
{
  ob_start();
  get_template_part($slug, $name, $args);
  return ob_get_clean();
}

function dd($args): void
{
  echo "<pre>";
  print_r($args);
  echo "</pre>";
  wp_die();
}

function get_svg_icon(string $name, int $size = 20): false|string
{
  $icon_path = get_template_directory() . "/src/images/icons/{$name}.svg";
  if (file_exists($icon_path)) {
    return file_get_contents($icon_path);
  } else {
    return '';
  };
};

/**
 * Create optimized AJAX tabs for news categories
 */
function create_optimized_ajax_tabs(array $tabData): string
{
  if (empty($tabData)) {
    return '';
  }

  $html = '<div class="ajax-tabs-container">';

  // Create tab navigation
  $html .= '<div class="tab-navigation flex border-b border-gray-200 mb-4">';
  foreach ($tabData as $index => $tab) {
    $activeClass = $index === 0 ? 'active' : '';
    $html .= sprintf(
      '<button class="tab-button %s px-4 py-2 mr-2 rounded-t-lg border-b-2 transition-colors duration-300" data-category="%s" data-bg-color="%s" data-border-color="%s">%s</button>',
      $activeClass,
      esc_attr($tab['slug']),
      esc_attr($tab['bg_color'] ?? 'bg-primary'),
      esc_attr($tab['border_color'] ?? 'border-primary'),
      esc_html($tab['name'])
    );
  }
  $html .= '</div>';

  // Create tab content container
  $html .= '<div class="tab-content-container">';
  $html .= '<div id="tab-loading" class="hidden text-center py-8">';
  $html .= '<div class="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>';
  $html .= '</div>';
  $html .= '<div id="tab-content" class="tab-content-area"></div>';
  $html .= '</div>';

  $html .= '</div>';

  // Add JavaScript for tab functionality
  $html .= '<script>
    document.addEventListener("DOMContentLoaded", function() {
      const tabButtons = document.querySelectorAll(".tab-button");
      const tabContent = document.getElementById("tab-content");
      const tabLoading = document.getElementById("tab-loading");
      
      // Load first tab content automatically
      if (tabButtons.length > 0) {
        loadTabContent(tabButtons[0]);
      }
      
      tabButtons.forEach(button => {
        button.addEventListener("click", function() {
          // Remove active class from all buttons
          tabButtons.forEach(btn => btn.classList.remove("active"));
          // Add active class to clicked button
          this.classList.add("active");
          // Load content
          loadTabContent(this);
        });
      });
      
      function loadTabContent(button) {
        const category = button.dataset.category;
        const bgColor = button.dataset.bgColor;
        const borderColor = button.dataset.borderColor;
        
        // Show loading
        tabLoading.classList.remove("hidden");
        tabContent.innerHTML = "";
        
        // Make AJAX request
        fetch(newsAjax.ajaxUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            action: "get_tab_news",
            category: category,
            borderColor: borderColor,
            bgColor: bgColor,
            nonce: newsAjax.nonce
          })
        })
        .then(response => response.json())
        .then(data => {
          tabLoading.classList.add("hidden");
          if (data.success) {
            tabContent.innerHTML = data.data;
          } else {
            tabContent.innerHTML = "<p>Error loading content.</p>";
          }
        })
        .catch(error => {
          tabLoading.classList.add("hidden");
          tabContent.innerHTML = "<p>Error loading content.</p>";
          console.error("Tab loading error:", error);
        });
      }
    });
  </script>';

  // Add CSS for tab styling
  $html .= '<style>
    .ajax-tabs-container .tab-button {
      background: #f3f4f6;
      color: #6b7280;
      border-bottom-color: transparent;
    }
    
    .ajax-tabs-container .tab-button:hover {
      background: #e5e7eb;
      color: #374151;
    }
    
    .ajax-tabs-container .tab-button.active {
      background: white;
      color: #1f2937;
      border-bottom-color: #3b82f6;
    }
    
    .tab-content-area {
      min-height: 300px;
    }
    
    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    
    .animate-spin {
      animation: spin 1s linear infinite;
    }
  </style>';

  return $html;
}

/**
 * Fallback shortcodes for optimized versions (redirect to NewsManager)
 */
function main_news_optimized_shortcode($atts, $content = null): string
{
  $newsManager = NewsManager::getInstance();
  $homepageData = $newsManager->getHomepageNewsData();
  return $newsManager->renderMainNews($homepageData['main_news']);
}
add_shortcode('main_news_optimized', 'main_news_optimized_shortcode');

function one_row_news_optimized_shortcode($atts, $content = null): string
{
  $atts = shortcode_atts([
    'slug' => '',
    'bg_color' => 'bg-gray-50',
    'cat_bg_color' => 'bg-primary',
    'border_color' => 'border-b-primary'
  ], $atts);

  if (empty($atts['slug'])) {
    return '';
  }

  $newsManager = NewsManager::getInstance();
  $homepageData = $newsManager->getHomepageNewsData();
  $posts = $homepageData['categories'][$atts['slug']] ?? [];

  return $newsManager->renderCategoryNews($atts['slug'], $posts, [
    'bg_color' => $atts['bg_color'],
    'cat_bg_color' => $atts['cat_bg_color'],
    'border_color' => $atts['border_color'],
    'per_page' => 4,
    'layout' => 'single_row'
  ]);
}
add_shortcode('one_row_news_optimized', 'one_row_news_optimized_shortcode');

function two_rows_news_optimized_shortcode($atts, $content = null): string
{
  $atts = shortcode_atts([
    'slug' => '',
    'bg_color' => 'bg-gray-50',
    'cat_bg_color' => 'bg-primary',
    'border_color' => 'border-b-primary'
  ], $atts);

  if (empty($atts['slug'])) {
    return '';
  }

  $newsManager = NewsManager::getInstance();
  $homepageData = $newsManager->getHomepageNewsData();
  $posts = $homepageData['categories'][$atts['slug']] ?? [];

  return $newsManager->renderCategoryNews($atts['slug'], $posts, [
    'bg_color' => $atts['bg_color'],
    'cat_bg_color' => $atts['cat_bg_color'],
    'border_color' => $atts['border_color'],
    'per_page' => 8,
    'layout' => 'double_row'
  ]);
}
add_shortcode('two_rows_news_optimized', 'two_rows_news_optimized_shortcode');

function two_cat_news_optimized_shortcode($atts, $content = null): string
{
  return '<div class="grid md:grid-cols-2 grid-cols-1 gap-4">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_cat_news_optimized', 'two_cat_news_optimized_shortcode');
