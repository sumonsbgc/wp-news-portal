<?php

/**
 * Infinite Scroll AJAX Handler
 */
class InfiniteScrollHandler
{
  public function __construct()
  {
    add_action('wp_ajax_load_infinite_posts', [$this, 'loadInfinitePosts']);
    add_action('wp_ajax_nopriv_load_infinite_posts', [$this, 'loadInfinitePosts']);
  }

  /**
   * Handle infinite scroll AJAX request
   */
  public function loadInfinitePosts(): void
  {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'infinite_scroll_nonce')) {
      wp_send_json_error('Invalid nonce');
      return;
    }

    $post_id = intval($_POST['post_id'] ?? 0);
    $page = intval($_POST['page'] ?? 1);
    $posts_per_page = 3; // Number of posts to load per request

    if (!$post_id) {
      wp_send_json_error('Invalid post ID');
      return;
    }

    // Get the current post to determine categories
    $current_post = get_post($post_id);
    if (!$current_post) {
      wp_send_json_error('Post not found');
      return;
    }

    // Get post categories
    $categories = wp_get_post_categories($post_id);

    // Query for related posts
    $args = [
      'post_type' => 'post',
      'posts_per_page' => $posts_per_page,
      'paged' => $page,
      'post__not_in' => [$post_id],
      'post_status' => 'publish',
      'orderby' => 'date',
      'order' => 'DESC'
    ];

    // If we have categories, get related posts from same categories
    if (!empty($categories)) {
      $args['category__in'] = $categories;
    }

    $query = new WP_Query($args);
    $posts_data = [];

    if ($query->have_posts()) {
      while ($query->have_posts()) {
        $query->the_post();

        $post_categories = get_the_category();
        $category_names = [];
        if ($post_categories) {
          foreach ($post_categories as $category) {
            $category_names[] = '<a href="' . get_category_link($category->term_id) . '">' . $category->name . '</a>';
          }
        }

        $posts_data[] = [
          'id' => get_the_ID(),
          'title' => get_the_title(),
          'permalink' => get_permalink(),
          'excerpt' => $this->getCustomExcerpt(get_the_content(), 150),
          'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
          'date' => get_the_date('F j, Y'),
          'author' => get_the_author(),
          'categories' => implode(', ', $category_names)
        ];
      }
      wp_reset_postdata();
    }

    // Check if there are more posts
    $has_more = $query->max_num_pages > $page;

    // If no posts found from categories, try to get random posts
    if (empty($posts_data) && $page === 1) {
      $args['category__in'] = [];
      $args['orderby'] = 'rand';
      $fallback_query = new WP_Query($args);

      if ($fallback_query->have_posts()) {
        while ($fallback_query->have_posts()) {
          $fallback_query->the_post();

          $post_categories = get_the_category();
          $category_names = [];
          if ($post_categories) {
            foreach ($post_categories as $category) {
              $category_names[] = '<a href="' . get_category_link($category->term_id) . '">' . $category->name . '</a>';
            }
          }

          $posts_data[] = [
            'id' => get_the_ID(),
            'title' => get_the_title(),
            'permalink' => get_permalink(),
            'excerpt' => $this->getCustomExcerpt(get_the_content(), 150),
            'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
            'date' => get_the_date('F j, Y'),
            'author' => get_the_author(),
            'categories' => implode(', ', $category_names)
          ];
        }
        wp_reset_postdata();
        $has_more = $fallback_query->max_num_pages > $page;
      }
    }

    wp_send_json_success([
      'posts' => $posts_data,
      'has_more' => $has_more,
      'current_page' => $page,
      'max_pages' => $query->max_num_pages ?? 0
    ]);
  }

  /**
   * Generate custom excerpt
   */
  private function getCustomExcerpt(string $content, int $length = 150): string
  {
    $content = wp_strip_all_tags($content);
    $content = wp_trim_words($content, $length / 8, '...');
    return $content;
  }
}

// Initialize the handler
new InfiniteScrollHandler();
