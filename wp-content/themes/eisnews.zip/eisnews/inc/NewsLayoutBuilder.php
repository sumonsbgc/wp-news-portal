<?php

class NewsLayoutBuilder
{
  private NewsPortal $newsPortal;

  public function __construct()
  {
    $this->newsPortal = new NewsPortal();
  }

  /**
   * Build the complete homepage layout
   */
  public function buildHomepage(): string
  {
    $html = '<div class="news-sections">';

    // Main news section
    $html .= $this->newsPortal->renderMainNews();

    // First two category grid
    $html .= $this->newsPortal->renderTwoCategoryGrid([
      [
        'slug' => 'chattogram',
        'layout' => 'double_row',
        'options' => [
          'bg_color' => 'bg-tile/20',
          'cat_bg_color' => 'bg-tile',
          'border_color' => 'border-b-tile'
        ]
      ],
      [
        'slug' => 'national',
        'layout' => 'double_row',
        'options' => [
          'bg_color' => 'bg-coal/20',
          'cat_bg_color' => 'bg-coal',
          'border_color' => 'border-b-coal'
        ]
      ]
    ]);

    // Single row news
    $html .= $this->newsPortal->renderSingleRowNews('zila-upazila-gram', [
      'bg_color' => 'bg-blue/5',
      'cat_bg_color' => 'bg-blue',
      'border_color' => 'border-b-blue'
    ]);

    // Second two category grid
    $html .= $this->newsPortal->renderTwoCategoryGrid([
      [
        'slug' => 'international',
        'layout' => 'double_row',
        'options' => [
          'bg_color' => 'bg-olive/20',
          'cat_bg_color' => 'bg-olive',
          'border_color' => 'border-b-olive'
        ]
      ],
      [
        'slug' => 'finance-trade',
        'layout' => 'double_row',
        'options' => [
          'bg_color' => 'bg-carrot/5',
          'cat_bg_color' => 'bg-carrot',
          'border_color' => 'border-b-carrot'
        ]
      ]
    ]);

    // Sports section
    $html .= $this->newsPortal->renderSingleRowNews('sports', [
      'bg_color' => 'bg-blue/5',
      'cat_bg_color' => 'bg-blue',
      'border_color' => 'border-b-blue'
    ]);

    // Tab news section
    $html .= $this->newsPortal->renderTabNews(get_tab_two_data());

    $html .= '</div>';

    return $html;
  }

  /**
   * Build category page layout
   */
  public function buildCategoryPage(string $categorySlug, array $options = []): string
  {
    $html = '<div class="category-page px-4">';
    $html .= eis_news_single_title();

    // Add show_title: false to options to prevent duplicate section title
    $options['show_title'] = false;
    $html .= $this->newsPortal->renderSingleRowNews($categorySlug, $options);
    $html .= '</div>';

    return $html;
  }

  /**
   * Build custom layout based on configuration
   */
  public function buildCustomLayout(array $config): string
  {
    $html = '<div class="custom-layout">';

    foreach ($config['sections'] as $section) {
      switch ($section['type']) {
        case 'main_news':
          $html .= $this->newsPortal->renderMainNews();
          break;

        case 'single_row':
          $html .= $this->newsPortal->renderSingleRowNews(
            $section['slug'],
            $section['options'] ?? []
          );
          break;

        case 'double_row':
          $html .= $this->newsPortal->renderDoubleRowNews(
            $section['slug'],
            $section['options'] ?? []
          );
          break;

        case 'two_category_grid':
          $html .= $this->newsPortal->renderTwoCategoryGrid($section['categories']);
          break;

        case 'tab_news':
          $html .= $this->newsPortal->renderTabNews($section['data']);
          break;

        case 'custom_html':
          $html .= $section['content'];
          break;
      }
    }

    $html .= '</div>';

    return $html;
  }
}