<?php

class PerformanceMonitor
{
  private static $start_time;
  private static $queries_count;

  public static function start(): void
  {
    self::$start_time = microtime(true);
    self::$queries_count = get_num_queries();
  }

  public static function end($label = 'Page Load'): void
  {
    if (!WP_DEBUG) return;

    $end_time = microtime(true);
    $execution_time = ($end_time - self::$start_time) * 1000; // Convert to milliseconds
    $queries_used = get_num_queries() - self::$queries_count;
    $memory_used = memory_get_peak_usage(true) / 1024 / 1024; // Convert to MB

    error_log(sprintf(
      '[PERFORMANCE] %s - Time: %.2fms | Queries: %d | Memory: %.2fMB',
      $label,
      $execution_time,
      $queries_used,
      $memory_used
    ));
  }

  public static function logCacheHit($cache_key, $hit = true): void
  {
    if (!WP_DEBUG) return;

    $status = $hit ? 'HIT' : 'MISS';
    error_log("[CACHE] {$status}: {$cache_key}");
  }
}

// Add performance monitoring to key functions
add_action('init', function () {
  if (WP_DEBUG && !is_admin()) {
    PerformanceMonitor::start();
  }
});

add_action('wp_footer', function () {
  if (WP_DEBUG && !is_admin()) {
    PerformanceMonitor::end('Homepage Load');
  }
});
