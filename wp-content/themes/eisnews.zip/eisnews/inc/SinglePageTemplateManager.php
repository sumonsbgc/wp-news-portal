<?php

/**
 * Single Page Template Manager
 * Handles different single page layouts and effects
 */
class SinglePageTemplateManager
{
  private static ?SinglePageTemplateManager $instance = null;
  private array $availableTemplates;

  private function __construct()
  {
    $this->availableTemplates = [
      'default' => [
        'name' => 'Default Layout',
        'description' => 'Standard single post layout with sidebar',
        'template' => 'single-default'
      ],
      'full-width' => [
        'name' => 'Full Width',
        'description' => 'Full width layout without sidebar',
        'template' => 'single-full-width'
      ],
      'full-width-infinite' => [
        'name' => 'Full Width with Infinite Scroll',
        'description' => 'Full width layout with infinite scroll for related posts',
        'template' => 'single-full-width-infinite'
      ],
      'parallax' => [
        'name' => 'Parallax Effect',
        'description' => 'Full width with parallax background effects',
        'template' => 'single-parallax'
      ],
      'minimal' => [
        'name' => 'Minimal',
        'description' => 'Clean, minimal design focused on content',
        'template' => 'single-minimal'
      ],
      'magazine' => [
        'name' => 'Magazine Style',
        'description' => 'Magazine-style layout with featured image',
        'template' => 'single-magazine'
      ]
    ];

    $this->initHooks();
  }

  public static function getInstance(): SinglePageTemplateManager
  {
    if (self::$instance === null) {
      self::$instance = new self();
    }
    return self::$instance;
  }

  /**
   * Initialize WordPress hooks
   */
  private function initHooks(): void
  {
    add_action('init', [$this, 'registerCustomFields']);
    add_action('add_meta_boxes', [$this, 'addTemplateMetaBox']);
    add_action('save_post', [$this, 'saveTemplateMetaBox']);
    add_filter('single_template', [$this, 'loadCustomTemplate']);
    add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);
  }

  /**
   * Register custom fields for template selection
   */
  public function registerCustomFields(): void
  {
    // This could be extended to use ACF or similar
  }

  /**
   * Add meta box for template selection
   */
  public function addTemplateMetaBox(): void
  {
    add_meta_box(
      'single_template_selector',
      'Single Page Template',
      [$this, 'renderTemplateMetaBox'],
      'post',
      'side',
      'high'
    );
  }

  /**
   * Render template selection meta box
   */
  public function renderTemplateMetaBox($post): void
  {
    wp_nonce_field('single_template_nonce', 'single_template_nonce');
    $selectedTemplate = get_post_meta($post->ID, '_single_template', true) ?: 'default';

    echo '<div class="single-template-selector">';
    foreach ($this->availableTemplates as $key => $template) {
      echo '<label style="display: block; margin-bottom: 10px;">';
      echo '<input type="radio" name="single_template" value="' . esc_attr($key) . '"' .
        checked($selectedTemplate, $key, false) . '> ';
      echo '<strong>' . esc_html($template['name']) . '</strong><br>';
      echo '<small>' . esc_html($template['description']) . '</small>';
      echo '</label>';
    }
    echo '</div>';
  }

  /**
   * Save template selection
   */
  public function saveTemplateMetaBox($post_id): void
  {
    if (
      !isset($_POST['single_template_nonce']) ||
      !wp_verify_nonce($_POST['single_template_nonce'], 'single_template_nonce')
    ) {
      return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
      return;
    }

    if (!current_user_can('edit_post', $post_id)) {
      return;
    }

    if (isset($_POST['single_template'])) {
      update_post_meta($post_id, '_single_template', sanitize_text_field($_POST['single_template']));
    }
  }

  /**
   * Load custom single template based on post meta
   */
  public function loadCustomTemplate($template): string
  {
    global $post;

    if (!is_single() || !isset($post->ID)) {
      return $template;
    }

    $selectedTemplate = get_post_meta($post->ID, '_single_template', true);

    if ($selectedTemplate && isset($this->availableTemplates[$selectedTemplate])) {
      $customTemplate = locate_template($this->availableTemplates[$selectedTemplate]['template'] . '.php');
      if ($customTemplate) {
        return $customTemplate;
      }
    }

    return $template;
  }

  /**
   * Enqueue necessary assets
   */
  public function enqueueAssets(): void
  {
    if (!is_single()) {
      return;
    }

    global $post;
    $selectedTemplate = get_post_meta($post->ID, '_single_template', true);

    // Enqueue template-specific assets
    switch ($selectedTemplate) {
      case 'full-width-infinite':
        wp_enqueue_script(
          'infinite-scroll',
          get_template_directory_uri() . '/assets/js/infinite-scroll.js',
          ['jquery'],
          VERSION,
          true
        );
        wp_localize_script('infinite-scroll', 'infiniteScroll', [
          'ajaxurl' => admin_url('admin-ajax.php'),
          'nonce' => wp_create_nonce('infinite_scroll_nonce'),
          'post_id' => $post->ID
        ]);
        break;

      case 'parallax':
        wp_enqueue_script(
          'parallax-effect',
          get_template_directory_uri() . '/assets/js/parallax.js',
          ['jquery'],
          VERSION,
          true
        );
        break;
    }

    // Enqueue common single page styles
    wp_enqueue_style(
      'single-templates',
      get_template_directory_uri() . '/assets/css/single-templates.css',
      [],
      VERSION
    );
  }

  /**
   * Get available templates
   */
  public function getAvailableTemplates(): array
  {
    return $this->availableTemplates;
  }

  /**
   * Get template data for a specific post
   */
  public function getPostTemplate($post_id): array
  {
    $selectedTemplate = get_post_meta($post_id, '_single_template', true) ?: 'default';
    return $this->availableTemplates[$selectedTemplate] ?? $this->availableTemplates['default'];
  }

  /**
   * Render post content with template-specific formatting
   */
  public function renderPostContent($post_id, $template_type = null): string
  {
    if (!$template_type) {
      $template_type = get_post_meta($post_id, '_single_template', true) ?: 'default';
    }

    $post = get_post($post_id);
    if (!$post) {
      return '';
    }

    switch ($template_type) {
      case 'full-width':
        return $this->renderFullWidthContent($post);
      case 'full-width-infinite':
        return $this->renderFullWidthInfiniteContent($post);
      case 'parallax':
        return $this->renderParallaxContent($post);
      case 'minimal':
        return $this->renderMinimalContent($post);
      case 'magazine':
        return $this->renderMagazineContent($post);
      default:
        return $this->renderDefaultContent($post);
    }
  }

  /**
   * Render default content layout
   */
  private function renderDefaultContent($post): string
  {
    $html = '<article class="single-post default-layout">';
    $html .= '<header class="post-header">';
    $html .= '<h1 class="post-title">' . get_the_title($post) . '</h1>';
    $html .= '<div class="post-meta">' . $this->getPostMeta($post) . '</div>';
    $html .= '</header>';

    if (has_post_thumbnail($post)) {
      $html .= '<div class="post-thumbnail">' . get_the_post_thumbnail($post, 'large') . '</div>';
    }

    $html .= '<div class="post-content">' . apply_filters('the_content', $post->post_content) . '</div>';
    $html .= '</article>';

    return $html;
  }

  /**
   * Render full width content layout
   */
  private function renderFullWidthContent($post): string
  {
    $html = '<article class="single-post full-width-layout">';
    $html .= '<div class="full-width-container">';

    if (has_post_thumbnail($post)) {
      $html .= '<div class="hero-image">';
      $html .= get_the_post_thumbnail($post, 'full', ['class' => 'w-full h-96 object-cover']);
      $html .= '<div class="hero-overlay">';
      $html .= '<h1 class="hero-title">' . get_the_title($post) . '</h1>';
      $html .= '<div class="hero-meta">' . $this->getPostMeta($post) . '</div>';
      $html .= '</div>';
      $html .= '</div>';
    } else {
      $html .= '<header class="post-header text-center py-16">';
      $html .= '<h1 class="text-4xl font-bold mb-4">' . get_the_title($post) . '</h1>';
      $html .= '<div class="post-meta">' . $this->getPostMeta($post) . '</div>';
      $html .= '</header>';
    }

    $html .= '<div class="content-wrapper max-w-4xl mx-auto px-4 py-8">';
    $html .= '<div class="post-content prose prose-lg mx-auto">';
    $html .= apply_filters('the_content', $post->post_content);
    $html .= '</div>';
    $html .= '</div>';
    $html .= '</div>';
    $html .= '</article>';

    return $html;
  }

  /**
   * Render full width with infinite scroll content
   */
  private function renderFullWidthInfiniteContent($post): string
  {
    $html = $this->renderFullWidthContent($post);

    // Add infinite scroll container
    $html .= '<div id="infinite-scroll-container" class="mt-16">';
    $html .= '<div class="max-w-4xl mx-auto px-4">';
    $html .= '<h3 class="text-2xl font-bold mb-8 text-center">Related Articles</h3>';
    $html .= '<div id="infinite-posts" class="space-y-8"></div>';
    $html .= '<div id="infinite-loading" class="text-center py-8 hidden">';
    $html .= '<div class="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>';
    $html .= '</div>';
    $html .= '</div>';
    $html .= '</div>';

    return $html;
  }

  /**
   * Render parallax content layout
   */
  private function renderParallaxContent($post): string
  {
    $featured_image = get_the_post_thumbnail_url($post, 'full');

    $html = '<article class="single-post parallax-layout">';

    if ($featured_image) {
      $html .= '<div class="parallax-hero" data-bg="' . esc_url($featured_image) . '">';
      $html .= '<div class="parallax-overlay">';
      $html .= '<div class="hero-content">';
      $html .= '<h1 class="parallax-title">' . get_the_title($post) . '</h1>';
      $html .= '<div class="parallax-meta">' . $this->getPostMeta($post) . '</div>';
      $html .= '</div>';
      $html .= '</div>';
      $html .= '</div>';
    }

    $html .= '<div class="parallax-content">';
    $html .= '<div class="content-wrapper max-w-4xl mx-auto px-4 py-16">';
    $html .= '<div class="post-content prose prose-lg mx-auto">';
    $html .= apply_filters('the_content', $post->post_content);
    $html .= '</div>';
    $html .= '</div>';
    $html .= '</div>';
    $html .= '</article>';

    return $html;
  }

  /**
   * Render minimal content layout
   */
  private function renderMinimalContent($post): string
  {
    $html = '<article class="single-post minimal-layout">';
    $html .= '<div class="minimal-container max-w-2xl mx-auto px-4 py-16">';
    $html .= '<header class="text-center mb-12">';
    $html .= '<h1 class="text-3xl font-light mb-6">' . get_the_title($post) . '</h1>';
    $html .= '<div class="minimal-meta text-sm text-gray-600">' . $this->getPostMeta($post) . '</div>';
    $html .= '</header>';

    $html .= '<div class="post-content prose prose-lg mx-auto">';
    $html .= apply_filters('the_content', $post->post_content);
    $html .= '</div>';
    $html .= '</div>';
    $html .= '</article>';

    return $html;
  }

  /**
   * Render magazine style content layout
   */
  private function renderMagazineContent($post): string
  {
    $html = '<article class="single-post magazine-layout">';

    if (has_post_thumbnail($post)) {
      $html .= '<div class="magazine-hero">';
      $html .= get_the_post_thumbnail($post, 'full', ['class' => 'magazine-featured-image']);
      $html .= '</div>';
    }

    $html .= '<div class="magazine-content">';
    $html .= '<div class="container mx-auto px-4 py-8">';
    $html .= '<div class="grid lg:grid-cols-3 gap-8">';

    // Main content area
    $html .= '<div class="lg:col-span-2">';
    $html .= '<header class="mb-8">';
    $html .= '<h1 class="text-4xl font-bold mb-4">' . get_the_title($post) . '</h1>';
    $html .= '<div class="magazine-meta flex items-center space-x-4">' . $this->getPostMeta($post) . '</div>';
    $html .= '</header>';

    $html .= '<div class="post-content prose prose-lg max-w-none">';
    $html .= apply_filters('the_content', $post->post_content);
    $html .= '</div>';
    $html .= '</div>';

    // Sidebar area
    $html .= '<div class="lg:col-span-1">';
    $html .= $this->getRelatedPosts($post, 5);
    $html .= '</div>';

    $html .= '</div>';
    $html .= '</div>';
    $html .= '</div>';
    $html .= '</article>';

    return $html;
  }

  /**
   * Get post meta information
   */
  private function getPostMeta($post): string
  {
    $meta = [];
    $meta[] = '<span class="post-date">' . get_the_date('F j, Y', $post) . '</span>';
    $meta[] = '<span class="post-author">By ' . get_the_author_meta('display_name', $post->post_author) . '</span>';

    $categories = get_the_category($post->ID);
    if ($categories) {
      $cat_links = array_map(function ($cat) {
        return '<a href="' . get_category_link($cat->term_id) . '">' . $cat->name . '</a>';
      }, $categories);
      $meta[] = '<span class="post-categories">' . implode(', ', $cat_links) . '</span>';
    }

    return implode(' • ', $meta);
  }

  /**
   * Get related posts
   */
  private function getRelatedPosts($post, $limit = 5): string
  {
    $categories = wp_get_post_categories($post->ID);

    $related_posts = get_posts([
      'post_type' => 'post',
      'numberposts' => $limit,
      'post__not_in' => [$post->ID],
      'category__in' => $categories,
      'orderby' => 'rand'
    ]);

    if (empty($related_posts)) {
      return '';
    }

    $html = '<div class="related-posts">';
    $html .= '<h3 class="text-xl font-bold mb-4">Related Articles</h3>';
    $html .= '<div class="space-y-4">';

    foreach ($related_posts as $related_post) {
      $html .= '<div class="related-post flex space-x-3">';
      if (has_post_thumbnail($related_post)) {
        $html .= '<div class="flex-shrink-0">';
        $html .= '<a href="' . get_permalink($related_post) . '">';
        $html .= get_the_post_thumbnail($related_post, 'thumbnail', ['class' => 'w-16 h-16 object-cover rounded']);
        $html .= '</a>';
        $html .= '</div>';
      }
      $html .= '<div class="flex-1">';
      $html .= '<h4 class="text-sm font-medium">';
      $html .= '<a href="' . get_permalink($related_post) . '" class="hover:text-blue-600">';
      $html .= get_the_title($related_post);
      $html .= '</a>';
      $html .= '</h4>';
      $html .= '<p class="text-xs text-gray-500 mt-1">' . get_the_date('M j, Y', $related_post) . '</p>';
      $html .= '</div>';
      $html .= '</div>';
    }

    $html .= '</div>';
    $html .= '</div>';

    return $html;
  }
}

// Initialize the template manager
SinglePageTemplateManager::getInstance();
