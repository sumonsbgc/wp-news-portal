<?php

class NewsApiController
{
  private NewsManager $newsManager;

  public function __construct()
  {
    $this->newsManager = NewsManager::getInstance();
    $this->registerAjaxHandlers();
  }

  /**
   * Register AJAX handlers
   */
  private function registerAjaxHandlers(): void
  {
    add_action("wp_ajax_get_tab_news", [$this, 'handleTabNewsRequest']);
    add_action("wp_ajax_nopriv_get_tab_news", [$this, 'handleTabNewsRequest']);

    add_action("wp_ajax_get_category_news", [$this, 'handleCategoryNewsRequest']);
    add_action("wp_ajax_nopriv_get_category_news", [$this, 'handleCategoryNewsRequest']);

    add_action("wp_ajax_load_more_news", [$this, 'handleLoadMoreRequest']);
    add_action("wp_ajax_nopriv_load_more_news", [$this, 'handleLoadMoreRequest']);
  }

  /**
   * Handle tab news AJAX requests
   */
  public function handleTabNewsRequest(): void
  {
    $this->validateAjaxRequest();

    $category = $this->sanitizeInput('category');
    $borderColor = $this->sanitizeInput('borderColor');
    $bgColor = $this->sanitizeInput('bgColor');

    if (empty($category)) {
      $this->sendJsonError('Category is required');
    }

    try {
      $html = $this->newsManager->getTabNewsAjax($category, $borderColor, $bgColor);
      $this->sendJsonSuccess($html);
    } catch (Exception $e) {
      $this->sendJsonError('Failed to load news: ' . $e->getMessage());
    }
  }

  /**
   * Handle category news requests
   */
  public function handleCategoryNewsRequest(): void
  {
    $this->validateAjaxRequest();

    $category = $this->sanitizeInput('category');
    $layout = $this->sanitizeInput('layout', 'single_row');
    $perPage = (int) $this->sanitizeInput('per_page', 4);

    if (empty($category)) {
      $this->sendJsonError('Category is required');
    }

    try {
      $newsPortal = new NewsPortal();

      if ($layout === 'double_row') {
        $html = $newsPortal->renderDoubleRowNews($category, ['per_page' => $perPage]);
      } else {
        $html = $newsPortal->renderSingleRowNews($category, ['per_page' => $perPage]);
      }

      $this->sendJsonSuccess($html);
    } catch (Exception $e) {
      $this->sendJsonError('Failed to load category news: ' . $e->getMessage());
    }
  }

  /**
   * Handle load more news requests
   */
  public function handleLoadMoreRequest(): void
  {
    $this->validateAjaxRequest();

    $category = $this->sanitizeInput('category');
    $page = (int) $this->sanitizeInput('page', 1);
    $perPage = (int) $this->sanitizeInput('per_page', 4);

    if (empty($category)) {
      $this->sendJsonError('Category is required');
    }

    try {
      $posts = new WP_Query([
        'category_name' => $category,
        'posts_per_page' => $perPage,
        'paged' => $page,
        'orderby' => ['date' => 'DESC'],
        'fields' => 'ids'
      ]);

      $html = '';
      if ($posts->have_posts()) {
        foreach ($posts->posts as $post_id) {
          $post_data = $this->newsManager->formatPostData($post_id);
          $html .= $this->newsManager->renderRegularNewsItem($post_data);
        }
      }

      $this->sendJsonSuccess([
        'html' => $html,
        'has_more' => $posts->max_num_pages > $page
      ]);
    } catch (Exception $e) {
      $this->sendJsonError('Failed to load more news: ' . $e->getMessage());
    }
  }

  /**
   * Validate AJAX request
   */
  private function validateAjaxRequest(): void
  {
    $nonce = $_POST['nonce'] ?? '';
    $action = $_POST['action'] ?? '';

    if (empty($action) || !wp_verify_nonce($nonce, 'news_ajax_nonce')) {
      $this->sendJsonError('Invalid request');
    }
  }

  /**
   * Sanitize input
   */
  private function sanitizeInput(string $key, string $default = ''): string
  {
    return sanitize_text_field($_POST[$key] ?? $default);
  }

  /**
   * Send JSON success response
   */
  private function sendJsonSuccess($data): void
  {
    wp_send_json_success($data);
    wp_die();
  }

  /**
   * Send JSON error response
   */
  private function sendJsonError(string $message): void
  {
    wp_send_json_error($message);
    wp_die();
  }
}

// Initialize the API controller
new NewsApiController();