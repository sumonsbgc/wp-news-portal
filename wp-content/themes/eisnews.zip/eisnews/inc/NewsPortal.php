<?php

class NewsPortal
{
  private NewsManager $newsManager;
  private array $homepageData;

  public function __construct()
  {
    $this->newsManager = NewsManager::getInstance();
    $this->loadHomepageData();
  }

  /**
   * Load all homepage data once
   */
  private function loadHomepageData(): void
  {
    $this->homepageData = $this->newsManager->getHomepageNewsData();
  }

  /**
   * Render breaking news section
   */
  public function renderBreakingNews(): string
  {
    return $this->newsManager->renderBreakingNews($this->homepageData['breaking_news']);
  }

  /**
   * Render main news section
   */
  public function renderMainNews(): string
  {
    return $this->newsManager->renderMainNews($this->homepageData['main_news']);
  }

  /**
   * Render single row category news
   */
  public function renderSingleRowNews(string $categorySlug, array $options = []): string
  {
    $defaults = [
      'bg_color' => 'bg-red-50',
      'cat_bg_color' => 'bg-primary',
      'border_color' => 'border-b-primary',
      'per_page' => 4
    ];

    $options = array_merge($defaults, $options);
    $posts = $this->homepageData['categories'][$categorySlug] ?? [];

    return $this->newsManager->renderCategoryNews($categorySlug, $posts, array_merge($options, [
      'layout' => 'single_row'
    ]));
  }

  /**
   * Render double row category news
   */
  public function renderDoubleRowNews(string $categorySlug, array $options = []): string
  {
    $defaults = [
      'bg_color' => 'bg-red-50',
      'cat_bg_color' => 'bg-primary',
      'border_color' => 'border-b-primary',
      'per_page' => 4
    ];

    $options = array_merge($defaults, $options);
    $posts = $this->homepageData['categories'][$categorySlug] ?? [];

    return $this->newsManager->renderCategoryNews($categorySlug, $posts, array_merge($options, [
      'layout' => 'double_row'
    ]));
  }

  /**
   * Render two category news in a grid
   */
  public function renderTwoCategoryGrid(array $categories): string
  {
    $html = '<div class="grid md:grid-cols-2 grid-cols-1 gap-4">';

    foreach ($categories as $category) {
      if ($category['layout'] === 'double_row') {
        $html .= $this->renderDoubleRowNews($category['slug'], $category['options']);
      } else {
        $html .= $this->renderSingleRowNews($category['slug'], $category['options']);
      }
    }

    $html .= '</div>';
    return $html;
  }

  /**
   * Render tab news section
   */
  public function renderTabNews(array $tabData): string
  {
    return create_optimized_ajax_tabs($tabData);
  }

  /**
   * Get all homepage sections in one call
   */
  public function getAllSections(): array
  {
    return [
      'breaking_news' => $this->renderBreakingNews(),
      'main_news' => $this->renderMainNews(),
      'categories' => $this->homepageData['categories']
    ];
  }
}
