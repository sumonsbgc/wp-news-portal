<?php

/**
 * Single Page Template Admin Interface
 */
class SinglePageTemplateAdmin
{
  public function __construct()
  {
    add_action('admin_menu', [$this, 'addAdminMenu']);
    add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
  }

  /**
   * Add admin menu
   */
  public function addAdminMenu(): void
  {
    add_theme_page(
      'Single Page Templates',
      'Page Templates',
      'manage_options',
      'single-page-templates',
      [$this, 'renderAdminPage']
    );
  }

  /**
   * Enqueue admin assets
   */
  public function enqueueAdminAssets($hook): void
  {
    if ($hook !== 'appearance_page_single-page-templates') {
      return;
    }

    wp_enqueue_style(
      'single-template-admin',
      get_template_directory_uri() . '/assets/css/admin-templates.css',
      [],
      VERSION
    );
  }

  /**
   * Render admin page
   */
  public function renderAdminPage(): void
  {
    $templateManager = SinglePageTemplateManager::getInstance();
    $templates = $templateManager->getAvailableTemplates();
?>
    <div class="wrap">
      <h1>Single Page Templates</h1>
      <p>Choose from different single page layouts to enhance your post presentation.</p>

      <div class="template-grid">
        <?php foreach ($templates as $key => $template): ?>
          <div class="template-card">
            <div class="template-preview">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/images/templates/<?php echo $key; ?>.png"
                alt="<?php echo esc_attr($template['name']); ?>"
                onerror="this.src='<?php echo get_template_directory_uri(); ?>/assets/images/templates/default.png'">
            </div>
            <div class="template-info">
              <h3><?php echo esc_html($template['name']); ?></h3>
              <p><?php echo esc_html($template['description']); ?></p>
              <div class="template-features">
                <?php echo $this->getTemplateFeatures($key); ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="template-instructions">
        <h2>How to Use</h2>
        <ol>
          <li>Edit any post in the WordPress admin</li>
          <li>Look for the "Single Page Template" meta box in the sidebar</li>
          <li>Select your desired template</li>
          <li>Update or publish the post</li>
          <li>View the post on the frontend to see the new layout</li>
        </ol>

        <h3>Template Features</h3>
        <div class="feature-explanations">
          <div class="feature-item">
            <h4>🎨 Full Width</h4>
            <p>Removes sidebar and utilizes the full width of the screen for a more immersive reading experience.</p>
          </div>
          <div class="feature-item">
            <h4>♾️ Infinite Scroll</h4>
            <p>Automatically loads related articles as the user scrolls down, keeping them engaged.</p>
          </div>
          <div class="feature-item">
            <h4>🌊 Parallax Effect</h4>
            <p>Creates a sophisticated scrolling effect with the featured image for visual appeal.</p>
          </div>
          <div class="feature-item">
            <h4>✨ Minimal Design</h4>
            <p>Clean, distraction-free layout that focuses entirely on the content.</p>
          </div>
          <div class="feature-item">
            <h4>📰 Magazine Style</h4>
            <p>Professional magazine-style layout with related articles sidebar.</p>
          </div>
        </div>
      </div>
    </div>
<?php
  }

  /**
   * Get template features HTML
   */
  private function getTemplateFeatures(string $templateKey): string
  {
    $features = [];

    switch ($templateKey) {
      case 'full-width':
        $features = ['Full Width', 'Hero Image', 'Responsive'];
        break;
      case 'full-width-infinite':
        $features = ['Full Width', 'Infinite Scroll', 'AJAX Loading'];
        break;
      case 'parallax':
        $features = ['Parallax Effect', 'Reading Progress', 'Smooth Animations'];
        break;
      case 'minimal':
        $features = ['Clean Design', 'Typography Focus', 'Distraction-free'];
        break;
      case 'magazine':
        $features = ['Magazine Layout', 'Related Posts', 'Professional'];
        break;
      default:
        $features = ['Standard Layout', 'Sidebar', 'Classic'];
        break;
    }

    $html = '<div class="template-tags">';
    foreach ($features as $feature) {
      $html .= '<span class="template-tag">' . esc_html($feature) . '</span>';
    }
    $html .= '</div>';

    return $html;
  }
}

// Initialize admin interface
if (is_admin()) {
  new SinglePageTemplateAdmin();
}
