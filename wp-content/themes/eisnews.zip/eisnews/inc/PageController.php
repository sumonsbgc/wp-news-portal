<?php

class PageController
{
  private NewsLayoutBuilder $layoutBuilder;

  public function __construct()
  {
    $this->layoutBuilder = new NewsLayoutBuilder();
  }

  /**
   * Handle homepage rendering
   */
  public function renderHomepage(): void
  {
    $this->renderPage([
      'template' => 'homepage',
      'content' => $this->layoutBuilder->buildHomepage(),
      'sidebar' => true
    ]);
  }

  /**
   * Handle category page rendering
   */
  public function renderCategoryPage(string $categorySlug): void
  {
    $options = $this->getCategoryOptions($categorySlug);

    $this->renderPage([
      'template' => 'category',
      'content' => $this->layoutBuilder->buildCategoryPage($categorySlug, $options),
      'sidebar' => true
    ]);
  }

  /**
   * Handle single post rendering
   */
  public function renderSinglePost(): void
  {
    if (have_posts()) {
      while (have_posts()) {
        the_post();
        $content = $this->buildSinglePostContent();

        $this->renderPage([
          'template' => 'single',
          'content' => $content,
          'sidebar' => true
        ]);
      }
    } else {
      $this->renderPage([
        'template' => 'single',
        'content' => '<p>No content found</p>',
        'sidebar' => true
      ]);
    }
  }

  /**
   * Render page with layout
   */
  private function renderPage(array $config): void
  {
    get_header();

    echo '<main class="content-area">';
    echo $config['content'];

    if ($config['sidebar']) {
      get_sidebar();
    }

    echo '</main>';

    get_footer();
  }

  /**
   * Build single post content
   */
  private function buildSinglePostContent(): string
  {
    $html = '<div class="news-sections">';
    $html .= '<article class="single-post">';

    if (has_post_thumbnail()) {
      $html .= '<div class="post-thumbnail">';
      $html .= get_the_post_thumbnail(null, 'large');
      $html .= '</div>';
    }

    $html .= '<header class="post-header">';
    $html .= '<h1 class="post-title">' . get_the_title() . '</h1>';

    // Add subheadings if they exist
    $subheading_1 = get_post_meta(get_the_ID(), 'subheading_1', true);
    $subheading_2 = get_post_meta(get_the_ID(), 'subheading_2', true);

    if ($subheading_1) {
      $html .= '<h2 class="post-subheading-1">' . esc_html($subheading_1) . '</h2>';
    }

    if ($subheading_2) {
      $html .= '<h3 class="post-subheading-2">' . esc_html($subheading_2) . '</h3>';
    }

    $html .= '<div class="post-meta">';
    $html .= '<span class="post-date">' . get_the_date() . '</span>';
    $html .= '<span class="post-author">By ' . get_the_author() . '</span>';
    $html .= '</div>';
    $html .= '</header>';

    $html .= '<div class="post-content">';
    $html .= get_the_content();
    $html .= '</div>';

    $html .= '<footer class="post-footer">';
    $html .= '<div class="post-categories">Categories: ' . get_the_category_list(', ') . '</div>';
    $html .= '</footer>';

    $html .= '</article>';
    $html .= '</div>';

    return $html;
  }

  /**
   * Get category-specific options
   */
  private function getCategoryOptions(string $categorySlug): array
  {
    $categoryOptions = [
      'chattogram' => [
        'bg_color' => 'bg-tile/20',
        'cat_bg_color' => 'bg-tile',
        'border_color' => 'border-b-tile'
      ],
      'national' => [
        'bg_color' => 'bg-coal/20',
        'cat_bg_color' => 'bg-coal',
        'border_color' => 'border-b-coal'
      ],
      'international' => [
        'bg_color' => 'bg-olive/20',
        'cat_bg_color' => 'bg-olive',
        'border_color' => 'border-b-olive'
      ],
      'finance-trade' => [
        'bg_color' => 'bg-carrot/5',
        'cat_bg_color' => 'bg-carrot',
        'border_color' => 'border-b-carrot'
      ],
      'sports' => [
        'bg_color' => 'bg-blue/5',
        'cat_bg_color' => 'bg-blue',
        'border_color' => 'border-b-blue'
      ],
      'zila-upazila-gram' => [
        'bg_color' => 'bg-blue/5',
        'cat_bg_color' => 'bg-blue',
        'border_color' => 'border-b-blue'
      ]
    ];

    return $categoryOptions[$categorySlug] ?? [
      'bg_color' => 'bg-gray-50',
      'cat_bg_color' => 'bg-gray-600',
      'border_color' => 'border-b-gray-600'
    ];
  }
}
