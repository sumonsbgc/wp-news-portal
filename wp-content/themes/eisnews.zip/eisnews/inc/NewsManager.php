<?php

class NewsManager
{
  private static $instance = null;
  private $cache_group = 'eis_news';
  private $cache_expiry = DAY_IN_SECONDS;

  public static function getInstance(): NewsManager
  {
    if (self::$instance === null) {
      self::$instance = new self();
    }
    return self::$instance;
  }

  /**
   * Get all homepage news data in a single optimized query
   */
  public function getHomepageNewsData(): array
  {
    $cache_key = 'homepage_news_data';
    $cached_data = wp_cache_get($cache_key, $this->cache_group);

    if ($cached_data !== false) {
      return $cached_data;
    }

    // Single query to get all needed posts
    $all_posts = new WP_Query([
      'post_type' => 'post',
      'post_status' => 'publish',
      'posts_per_page' => 50, // Adjust based on your needs
      'orderby' => ['date' => 'DESC', 'menu_order' => 'ASC'],
      'meta_query' => [
        'relation' => 'OR',
        [
          'key' => '_breaking_news',
          'value' => '1',
          'compare' => '='
        ],
        [
          'key' => '_breaking_news',
          'compare' => 'NOT EXISTS'
        ]
      ]
    ]);

    $categorized_posts = [
      'breaking_news' => [],
      'main_news' => [],
      'categories' => []
    ];

    if ($all_posts->have_posts()) {
      while ($all_posts->have_posts()) {
        $all_posts->the_post();
        $post_id = get_the_ID();
        $categories = get_the_category($post_id);

        // Check if it's breaking news
        if (get_post_meta($post_id, '_breaking_news', true) === '1') {
          $categorized_posts['breaking_news'][] = $this->formatPostData($post_id);
        }

        foreach ($categories as $category) {
          $slug = $category->slug;

          // Main news
          if ($slug === 'main-news') {
            if (count($categorized_posts['main_news']) < 7) {
              $categorized_posts['main_news'][] = $this->formatPostData($post_id, true);
            }
          }

          // Category-specific news
          if (!isset($categorized_posts['categories'][$slug])) {
            $categorized_posts['categories'][$slug] = [];
          }

          if (count($categorized_posts['categories'][$slug]) < 8) {
            $categorized_posts['categories'][$slug][] = $this->formatPostData($post_id);
          }
        }
      }
      wp_reset_postdata();
    }

    wp_cache_set($cache_key, $categorized_posts, $this->cache_group, $this->cache_expiry);
    return $categorized_posts;
  }

  /**
   * Format post data for template use
   */
  public function formatPostData(int $post_id, bool $include_sticky = false): array
  {
    return [
      'id' => $post_id,
      'title' => get_the_title($post_id),
      'permalink' => get_permalink($post_id),
      'thumbnail' => get_the_post_thumbnail_url($post_id, 'small_news_thumb'),
      'excerpt' => get_the_excerpt($post_id),
      'date' => get_the_date('', $post_id),
      'is_sticky' => $include_sticky ? is_sticky($post_id) : false,
      'categories' => wp_get_post_categories($post_id, ['fields' => 'names'])
    ];
  }

  /**
   * Generate breaking news HTML
   */
  public function renderBreakingNews(array $posts): string
  {
    if (empty($posts)) {
      return '';
    }

    $html = '<ul id="news-ticker-wrap" class="h-full flex gap-2">';
    foreach (array_slice($posts, 0, 10) as $post) {
      $html .= sprintf(
        '<li class="h-full flex flex-shrink-0">
                    <a href="%s" class="flex items-center font-normal text-base font-kalpurush h-full gap-1 flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m5.25 4.5 7.5 7.5-7.5 7.5m6-15 7.5 7.5-7.5 7.5" />
                        </svg>
                        <span>%s</span>
                    </a>
                </li>',
        esc_url($post['permalink']),
        esc_html($post['title'])
      );
    }
    $html .= '</ul>';
    return $html;
  }

  /**
   * Generate main news section HTML
   */
  public function renderMainNews(array $posts): string
  {
    if (empty($posts)) {
      return '';
    }

    $html = '<div>';
    $html .= eis_main_news_section_title();
    $html .= '<div class="grid md:grid-cols-4 sm:grid-cols-3 grid-cols-2 sm:grid-rows-3 gap-4">';

    foreach (array_slice($posts, 0, 7) as $post) {
      if ($post['is_sticky']) {
        $html .= $this->renderLargeNewsItem($post);
      } else {
        $html .= $this->renderRegularNewsItem($post);
      }
    }

    $html .= '</div>';
    $html .= '</div>';
    return $html;
  }

  /**
   * Generate category news section HTML
   */
  public function renderCategoryNews(string $category_slug, array $posts, array $options = []): string
  {
    $defaults = [
      'bg_color' => 'bg-red-50',
      'cat_bg_color' => 'bg-primary',
      'border_color' => 'border-b-primary',
      'per_page' => 4,
      'layout' => 'single_row', // single_row, double_row
      'show_title' => true // Whether to show section title
    ];

    $options = array_merge($defaults, $options);

    if (empty($posts)) {
      return '';
    }

    $html = '<div class="my-2">';

    // Only show title if show_title option is true
    if ($options['show_title']) {
      $html .= eis_news_section_title($category_slug, $options['border_color'], $options['cat_bg_color']);
    }

    if ($options['layout'] === 'double_row') {
      $html .= '<div class="grid md:grid-cols-2 sm:grid-cols-2 grid-cols-1 gap-4">';
      $posts_per_row = ceil($options['per_page'] / 2);
    } else {
      $html .= '<div class="grid md:grid-cols-4 sm:grid-cols-3 grid-cols-2 gap-4">';
      $posts_per_row = $options['per_page'];
    }

    foreach (array_slice($posts, 0, $options['per_page']) as $post) {
      $html .= $this->renderRegularNewsItem($post, $options['bg_color'], $options['border_color']);
    }

    $html .= '</div>';
    $html .= '</div>';
    return $html;
  }

  /**
   * Render a large news item (for sticky posts)
   */
  private function renderLargeNewsItem(array $post): string
  {
    return sprintf(
      '<div class="md:col-span-2 md:row-span-2 bg-white border-b-2 border-primary">
                <a href="%s">
                    <img src="%s" alt="%s" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h2 class="text-xl font-bold mb-2">%s</h2>
                        <p class="text-gray-600">%s</p>
                    </div>
                </a>
            </div>',
      esc_url($post['permalink']),
      esc_url($post['thumbnail']),
      esc_attr($post['title']),
      esc_html($post['title']),
      esc_html($post['excerpt'])
    );
  }

  /**
   * Render a regular news item
   */
  public function renderRegularNewsItem(array $post, string $bg_color = 'bg-white', string $border_color = 'border-b-primary'): string
  {
    return sprintf(
      '<div class="%s border-b-2 %s">
                <a href="%s">
                    <img src="%s" alt="%s" class="w-full h-32 object-cover">
                    <div class="p-3">
                        <h3 class="font-semibold text-sm mb-1">%s</h3>
                        <p class="text-xs text-gray-600">%s</p>
                    </div>
                </a>
            </div>',
      $bg_color,
      $border_color,
      esc_url($post['permalink']),
      esc_url($post['thumbnail']),
      esc_attr($post['title']),
      esc_html($post['title']),
      esc_html(wp_trim_words($post['excerpt'], 15))
    );
  }

  /**
   * Generate tab news for AJAX
   */
  public function getTabNewsAjax(string $category, string $border_color, string $bg_color): string
  {
    $cache_key = "tab_news_{$category}";
    $cached_html = wp_cache_get($cache_key, $this->cache_group);

    if ($cached_html !== false) {
      return $cached_html;
    }

    $posts = new WP_Query([
      'category_name' => $category,
      'posts_per_page' => 5,
      'orderby' => ['date' => 'DESC'],
      'fields' => 'ids' // Only get IDs first for better performance
    ]);

    $html = '';
    if ($posts->have_posts()) {
      $post_ids = $posts->posts;
      foreach ($post_ids as $index => $post_id) {
        $post_data = $this->formatPostData($post_id);
        if ($index === 0) {
          $html .= $this->renderLargeNewsItem($post_data);
        } else {
          $html .= $this->renderRegularNewsItem($post_data, 'bg-white', $border_color);
        }
      }

      $link = eis_get_category_link($category);
      $html .= sprintf(
        '<a href="%s" class="more active %s"><span>আরোও</span> %s</a>',
        $link,
        $bg_color,
        get_svg_icon('right-angle')
      );
    } else {
      $html = 'No posts found for the selected category.';
    }

    wp_cache_set($cache_key, $html, $this->cache_group, $this->cache_expiry);
    return $html;
  }

  /**
   * Clear all related caches
   */
  public function clearCache(int $post_id = null): void
  {
    wp_cache_delete('homepage_news_data', $this->cache_group);

    if ($post_id) {
      $categories = get_the_category($post_id);
      foreach ($categories as $category) {
        wp_cache_delete("tab_news_{$category->slug}", $this->cache_group);
      }
    }

    // Clear old cache keys for backward compatibility
    wp_cache_delete('breaking_news');
    wp_cache_delete('main_news');
  }
}