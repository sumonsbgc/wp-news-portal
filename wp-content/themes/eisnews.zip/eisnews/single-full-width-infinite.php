<?php

/**
 * Single Post Template - Full Width with Infinite Scroll
 */

$templateManager = SinglePageTemplateManager::getInstance();
$post_id = get_the_ID();

get_header(); ?>

<main class="single-full-width-infinite">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <?php echo $templateManager->renderPostContent($post_id, 'full-width-infinite'); ?>
  <?php endwhile;
  endif; ?>
</main>

<?php get_footer(); ?>