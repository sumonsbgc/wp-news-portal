<?php

/**
 * Usage Examples for OOP News Portal
 */

// Example 1: Basic usage in templates
function example_basic_usage()
{
  // Create a news portal instance
  $newsPortal = new NewsPortal();

  // Render different sections
  echo $newsPortal->renderMainNews();
  echo $newsPortal->renderSingleRowNews('sports');
  echo $newsPortal->renderDoubleRowNews('national');
}

// Example 2: Custom layout configuration
function example_custom_layout()
{
  $layoutBuilder = new NewsLayoutBuilder();

  $customConfig = [
    'sections' => [
      [
        'type' => 'main_news'
      ],
      [
        'type' => 'two_category_grid',
        'categories' => [
          [
            'slug' => 'tech',
            'layout' => 'single_row',
            'options' => [
              'bg_color' => 'bg-blue/5',
              'cat_bg_color' => 'bg-blue',
              'border_color' => 'border-b-blue'
            ]
          ],
          [
            'slug' => 'business',
            'layout' => 'double_row',
            'options' => [
              'bg_color' => 'bg-green/5',
              'cat_bg_color' => 'bg-green',
              'border_color' => 'border-b-green'
            ]
          ]
        ]
      ],
      [
        'type' => 'custom_html',
        'content' => '<div class="advertisement"><!-- Ad content --></div>'
      ]
    ]
  ];

  echo $layoutBuilder->buildCustomLayout($customConfig);
}

// Example 3: Direct usage without controllers
function example_direct_usage()
{
  $newsManager = NewsManager::getInstance();
  $homepageData = $newsManager->getHomepageNewsData();

  // Access raw data
  $breakingNews = $homepageData['breaking_news'];
  $mainNews = $homepageData['main_news'];
  $categories = $homepageData['categories'];

  // Custom rendering
  foreach ($categories['sports'] as $post) {
    echo "<h3>{$post['title']}</h3>";
    echo "<p>{$post['excerpt']}</p>";
  }
}

// Example 4: Creating custom page templates
function create_custom_page_template($categorySlug)
{
?>
  <!DOCTYPE html>
  <html>

  <head>
    <title>Custom News Page</title>
  </head>

  <body>
    <?php
    $pageController = new PageController();
    $pageController->renderCategoryPage($categorySlug);
    ?>
  </body>

  </html>
<?php
}

// Example 5: AJAX integration
function example_ajax_integration()
{
?>
  <script>
    // Using the OOP AJAX system
    jQuery.ajax({
      url: newsAjax.ajaxUrl,
      type: 'POST',
      data: {
        action: 'get_category_news',
        category: 'sports',
        layout: 'single_row',
        per_page: 6,
        nonce: newsAjax.nonce
      },
      success: function(response) {
        if (response.success) {
          jQuery('#news-container').html(response.data);
        }
      }
    });
  </script>
<?php
}

// Example 6: Performance monitoring
function example_performance_monitoring()
{
  PerformanceMonitor::start();

  $newsPortal = new NewsPortal();
  echo $newsPortal->renderMainNews();

  PerformanceMonitor::end('Main News Rendering');
}
