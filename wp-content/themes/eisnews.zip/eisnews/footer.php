</div>
<footer class="bg-slate-50">
  <div class="grid sm:grid-cols-4 grid-cols-2 py-6 container">
    <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet maxime placeat, perspiciatis rerum aperiam, repellat voluptatem similique optio consequuntur maiores animi dolor ducimus. Illum nisi molestias incidunt deleniti esse nobis?</div>
    <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet maxime placeat, perspiciatis rerum aperiam, repellat voluptatem similique optio consequuntur maiores animi dolor ducimus. Illum nisi molestias incidunt deleniti esse nobis?</div>
    <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet maxime placeat, perspiciatis rerum aperiam, repellat voluptatem similique optio consequuntur maiores animi dolor ducimus. Illum nisi molestias incidunt deleniti esse nobis?</div>
    <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet maxime placeat, perspiciatis rerum aperiam, repellat voluptatem similique optio consequuntur maiores animi dolor ducimus. Illum nisi molestias incidunt deleniti esse nobis?</div>
  </div>
</footer>
<!-- <div class="sm:hidden flex bg-slate-300 justify-center sticky bottom-0 w-full">
  <ul class="flex gap-4 justify-evenly">
    <li>
      <span class="p2">Sidebar</span>
    </li>
    <li>
      <span class="p2">Sidebar</span>
    </li>
    <li>
      <span class="p2">Sidebar</span>
    </li>
  </ul>
</div> -->
<?php wp_footer(); ?>
</body>

</html>