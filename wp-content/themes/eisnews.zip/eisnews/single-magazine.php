<?php

/**
 * Single Post Template - Magazine Style
 */

$templateManager = SinglePageTemplateManager::getInstance();
$post_id = get_the_ID();

get_header(); ?>

<main class="single-magazine">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <?php echo $templateManager->renderPostContent($post_id, 'magazine'); ?>
  <?php endwhile;
  endif; ?>
</main>

<?php get_footer(); ?>