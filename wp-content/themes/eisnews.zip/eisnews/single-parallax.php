<?php

/**
 * Single Post Template - Parallax Effect
 */

$templateManager = SinglePageTemplateManager::getInstance();
$post_id = get_the_ID();

get_header(); ?>

<main class="single-parallax">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <?php echo $templateManager->renderPostContent($post_id, 'parallax'); ?>
  <?php endwhile;
  endif; ?>
</main>

<?php get_footer(); ?>